//
//  OrderLogCellTableViewCell.swift
//  PA13_LemonadeStand
//
//  Created by David Sally on 4/13/17.
//  Copyright © 2017 David Sally. All rights reserved.
//

import UIKit

class OrderLogCellTableViewCell: UITableViewCell {

	@IBOutlet var orderNum: UILabel!
	@IBOutlet var drinkLabel: UILabel!
	@IBOutlet var sizeLabel: UILabel!

}
